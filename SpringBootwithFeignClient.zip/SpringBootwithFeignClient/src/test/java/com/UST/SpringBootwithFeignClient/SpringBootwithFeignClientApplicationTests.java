package com.UST.SpringBootwithFeignClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootwithFeignClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
