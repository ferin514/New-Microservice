package com.UST.StudentServicesfeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentServicesfeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServicesfeignApplication.class, args);
	}

}
